# Handoff: CollabSync VST Plugin UI

## Overview
CollabSync is a VST plugin that lets two musicians run a peer-to-peer session, record together, and exchange the resulting files. This handoff covers a full visual redesign of the plugin window: a dark forest-green neumorphic surface with cream text, a subtle grain texture, a lean status strip, and a generated-files preview area (waveform for audio, piano-roll for MIDI) shown after a take finishes.

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype showing intended look and behavior, **not** production code to copy directly. The `CollabSync UI.dc.html` file uses a small custom component runtime (`.dc.html` + `support.js`) purely so it renders in the design tool; **do not** carry that runtime into the plugin.

Your task is to **recreate this design in the plugin's actual UI environment**. VST UIs are commonly built with **JUCE (C++)** or a web-based framework (React inside a WebView, e.g. via `juce_gui_extra` WebBrowserComponent, or iPlug2's web UI). Use whatever the existing codebase already uses and follow its established patterns. If no UI layer exists yet, JUCE with the `juce::Graphics`/`LookAndFeel` system, or a React-in-WebView layer, are both reasonable — pick one and implement the design there. Everything below is specified in framework-neutral terms (colors, sizes, typography, shadows) so it maps to either.

## Fidelity
**High-fidelity (hifi).** Colors, typography, spacing, shadows, and state behavior are final. Recreate the UI to match these values. The one caveat: the waveform and piano-roll drawings in the prototype are **placeholder data visualizations** — in the plugin they must render the *real* audio waveform and MIDI note data. Match their visual style (bar/note color, height, spacing, corner radius), not the exact fake shapes.

## Window / Layout

The plugin window is a single vertical panel. It is **resizable**; three reference widths are provided (the prototype's S/M/L toggle is a design aid only — **not** part of the shipped UI):

- **Compact (S):** 380 px wide
- **Standard (M):** 620 px wide  *(primary target)*
- **Wide (L):** 800 px wide

Height is content-driven. `max-width: 100%`; content reflows within the width.

**Panel container**
- Background: radial gradient — `radial-gradient(circle at 30% 12%, #052a1c, #032018 55%, #02150e)`
- Corners: **square** (border-radius `0`) — VST windows are not rounded.
- Inset bevel for depth: `box-shadow: inset 6px 6px 16px rgba(0,0,0,.55), inset -6px -6px 16px rgba(120,220,175,.04), 0 30px 70px -24px rgba(0,0,0,.8)`
- **Grain overlay:** a full-bleed noise layer over the panel, `mix-blend-mode: overlay`, `pointer-events: none`. In the prototype it's a tiling fractal-noise SVG (`feTurbulence`, `baseFrequency 0.9`, `numOctaves 2`). Opacity ≈ `grain% / 100 × 0.7` (default grain 35 → ~0.245). Reproduce with any fine film-grain/noise texture at low opacity. Keep it subtle.
- Inner content padding: `28px`.

**Vertical order inside the panel:**
1. Header row — title + connection status (top-right)
2. Divider
3. Host section (label + peer status; session controls)
4. Divider
5. Host IP section (input + Connect/Disconnect)
6. Record button
7. Status indicator strip
8. Generated Files preview grid *(only after a take finishes)*

Dividers are a 1px hairline: `linear-gradient(90deg, transparent, rgba(0,10,7,.6) 20%, rgba(120,220,175,.05) 80%, transparent)`, `margin: 22px 0`.

## Components

### Header
- Title **"CollabSync"** — DM Sans, 22px, weight 700, letter-spacing −.02em, color `#eaf1e6`.
- Version **"0.7.0"** next to it — DM Mono, 12px, color `rgba(234,241,230,.34)`.
- **Connection status** (right): a small dot + label, DM Mono 12px. Dot is 8px. See Status colors below.

### Host section
- Label **"Host"** — DM Mono, 11px, letter-spacing .2em, uppercase, `rgba(234,241,230,.5)`.
- Peer status text (right) — DM Mono 12px, Title Case, color per state (see below).
- **When a session is active:** an IP readout well showing the local IP (e.g. `100.93.223.36`) + a **Copy IP** button; below, a full-width **Stop Session** button.
- **When idle:** helper line "Start a session for your friend to join." (`rgba(234,241,230,.42)`, 13px) + a full-width **Start Session** button.

### Host IP section
- Label **"Host IP"** (same style as "Host").
- Input well showing the host address (e.g. `localhost`).
- Two buttons in a 2-column grid, gap 12px: **Connect** (primary weight 700, cream text) and **Disconnect** (weight 600, `rgba(234,241,230,.55)`).

### Input wells (recessed fields)
- Background `#02130c`, height 52px, border-radius 13px, horizontal padding 16px.
- Recessed shadow: `inset 5px 5px 11px rgba(0,0,0,.75), inset -3px -3px 9px rgba(95,216,166,.07)`
- Value text: DM Mono 15px, `#eaf1e6`.

### Buttons (neumorphic, raised)
All primary/secondary buttons share **one fill and one shadow** — hierarchy comes from text weight/color only, not fill:
- Fill: `#073c28`
- Raised shadow: `6px 6px 14px rgba(0,0,0,.5), -5px -5px 12px rgba(120,220,175,.07), inset 0 1px 0 rgba(150,230,190,.10)`
- Border-radius 13–14px, no border, DM Sans.
- Primary (Start Session / Connect / Record-ready): weight 700, text `#eaf1e6`.
- Secondary (Copy IP / Stop Session): weight 600, text `#cfe6da` / `rgba(234,241,230,.72)`.
- De-emphasized (Disconnect): weight 600, text `rgba(234,241,230,.55)`.

### Record button (full width, height 56px, radius 14px)
Three visual states:
- **Ready** (connected, not recording): fill `#073c28`, cream text, standard raised neumorphic shadow, small red armed dot (9px, `#e8564b`, glow `0 0 7px`). Label "Record".
- **Disabled** (idle/hosting — no peer): recessed, fill `#02130c`, text `rgba(234,241,230,.24)`, `cursor: not-allowed`, shadow `inset 5px 5px 11px rgba(0,0,0,.72), inset -3px -3px 9px rgba(95,216,166,.06)`. Label "Record".
- **Recording**: fill `linear-gradient(145deg,#2a0e0b,#160705)`, text red `#e8564b`, 11px red dot with `0 0 10px` glow, and an animated red pulse (see Animations). Label "Recording".

### Status indicator strip
A recessed well (background `#02130c`, radius 14px, padding 14px 16px, shadow `inset 5px 5px 11px rgba(0,0,0,.72), inset -3px -3px 9px rgba(95,216,166,.07)`) containing a horizontal row (gap 22px, wraps) of five indicators, each = a 9px dot + a DM Mono 10px uppercase label (letter-spacing .16em).

Indicators, in order: **Conn, Sync, MIDI, Audio, Rec.**
- **Off dot:** background `#00160f`, recessed `inset 1px 1px 2px rgba(0,0,0,.7), inset -1px -1px 2px rgba(95,216,166,.05)`; label color `rgba(234,241,230,.32)`.
- **On dot:** solid color fill + `0 0 8px <color>` glow; label color `rgba(234,241,230,.72)`. Optionally pulses (see Animations).
- Colors: Conn/Sync/MIDI/Audio = mint `#5fd8a6`; **Rec = red `#e8564b`**; a *pending* Conn (hosting, waiting for peer) = amber `#e2a15a` and pulses.

### Generated Files preview (shown only after a take finishes)
- Section label **"Generated Files"** (DM Mono 11px .2em uppercase `rgba(234,241,230,.5)`) with a right-aligned hint **"drag any file into your DAW ↗"** (DM Mono 10px `rgba(234,241,230,.32)`).
- Grid: `1fr 1fr` (two columns), collapsing to a single column when panel width < 520px. Gap 12px. Up to **4 cards**: You·Audio, You·MIDI, Peer·Audio, Peer·MIDI.
- **Card:** recessed well — padding `15px 15px 14px`, radius 15px, background `#02130c`, shadow `inset 5px 5px 11px rgba(0,0,0,.72), inset -3px -3px 9px rgba(95,216,166,.07)`, `cursor: grab` (cards are drag sources onto the DAW).
- Card header: owner + type — "You · Audio" etc. Owner in DM Sans 13px weight 600 `#eaf1e6`; " · Audio/MIDI" in DM Mono 11px `rgba(234,241,230,.4)`. A drag-grip glyph `⠿` on the right (`rgba(234,241,230,.3)`).
- **Audio card body:** waveform — a row of vertical bars, 52px tall, 2px gap, each bar 2px min-width, radius 2px. Heights follow the real audio envelope. Color: **You = `rgba(234,241,230,.62)` (cream), Peer = `rgba(95,216,166,.55)` (mint).**
- **MIDI card body:** piano-roll — 52px tall relative box with note blocks (radius 3px) positioned by pitch (row) and time (x). Same You=cream / Peer=mint color rule.
- Card footer: filename (DM Mono 11px `rgba(234,241,230,.5)`, e.g. `take_01.wav`, `peer_01.mid`) + metadata right-aligned (`rgba(234,241,230,.32)`, e.g. duration `0:48` for audio, `32 notes` for MIDI).

## Status colors (connection status + host peer status)
| State | Header status text | Header dot | Host peer text |
|---|---|---|---|
| Idle | "Not connected" — dim `rgba(234,241,230,.22)` | off (`#00160f`, recessed) | "Inactive" — dim |
| Hosting | "Waiting for peer…" — amber glow | amber `#e2a15a`, glow, **pulsing** | "Hosting — Waiting" — amber glow |
| Connected | "Connected" — mint glow | mint `#5fd8a6`, glow | "Peer Connected" — mint glow |
| Recording | "Recording…" — red glow | red `#e8564b`, glow, **pulsing** | "Peer Connected" — mint glow |
| Finished | "Connected" — mint glow | mint, glow | "Peer Connected" — mint glow |

Glow text = brighter tint + text-shadow:
- mint glow → color `#8ef0c2`, `text-shadow: 0 0 12px rgba(95,216,166,.6)`
- amber glow → color `#f0bd82`, `text-shadow: 0 0 12px rgba(226,161,90,.55)`
- red glow → color `#f2837a`, `text-shadow: 0 0 12px rgba(232,86,75,.55)`
- off → color `rgba(234,241,230,.22)`, no shadow

## Interactions & Behavior
- **Start Session**: opens a hosting session → status goes to Hosting (amber, "Waiting for peer…"), local IP appears in the Host well, Record button disabled.
- **Peer connects**: status → Connected (mint), Record button enabled.
- **Connect / Disconnect** (Host IP section): join / leave a remote host by address.
- **Copy IP**: copies the local IP string to clipboard.
- **Record**: enabled only when a peer is connected. Click → Recording state (red, pulsing). Click again / stop → take finishes.
- **Take finishes**: Generated Files grid appears with up to 4 cards (local + remote, audio + MIDI). Each card is a **drag source** — dragging it initiates a file drag-and-drop into the host DAW (VST drag-export).
- **Responsive**: single-column preview grid below 520px width; panel content reflows to the current window width.

## Animations
- **`dotpulse`** (pending/recording dots): 1.1s ease-in-out infinite. Midpoint reduces opacity to ~.6 and expands the glow (`0 0 12px 2px <color>`). Applied to the amber hosting dot and the red recording dot.
- **`recpulse`** (recording button): 1.4s ease-in-out infinite. Pulses an inset + outer red glow:
  - 0/100%: `inset 5px 5px 11px rgba(0,8,5,.55), inset -4px -4px 10px rgba(230,90,80,.10), 0 0 0 0 rgba(230,90,80,0)`
  - 50%: `inset 5px 5px 11px rgba(0,8,5,.55), inset -4px -4px 10px rgba(230,90,80,.20), 0 0 22px 1px rgba(230,90,80,.26)`
- Panel width change: `transition: width .28s cubic-bezier(.4,0,.2,1)` (cosmetic — real window resize is host-driven).

## State Management
Core UI state is a single session enum: **`idle → hosting → connected → recording → finished`**, plus per-state activity flags driving the indicator strip:

| State | Conn | Sync | MIDI | Audio | Rec |
|---|---|---|---|---|---|
| idle | off | off | off | off | off |
| hosting | pending (amber, pulse) | off | off | off | off |
| connected | on | on | off | off | off |
| recording | on | on | on (live) | on (live) | pending (red, pulse) |
| finished | on | on | off | off | off |

- MIDI / Audio indicators reflect **live input activity** during recording (drive them from real MIDI-in and audio-input meters).
- Sync = peers in sync; Conn = peer connection; Rec = recording armed/live.
- Data needed: local IP, host address, connection/peer state, live input activity, and on finish, the 4 generated files (path, type, duration or note count, waveform/MIDI data for preview).

## Design Tokens
**Colors**
- Panel gradient: `#052a1c` → `#032018` → `#02150e`
- Recessed surfaces (wells, cards, disabled): `#02130c`
- Button fill: `#073c28`
- Text primary (cream): `#eaf1e6`
- Text muted: `rgba(234,241,230,.5)` / `.42` / `.34` / `.32` / `.22`
- Mint (connected/sync, accent, links): `#5fd8a6`; bright `#8ef0c2`
- Amber (hosting/pending): `#e2a15a`; bright `#f0bd82`
- Red (recording): `#e8564b`; bright `#f2837a`
- Peer waveform/MIDI: `rgba(95,216,166,.55)`; Local (you): `rgba(234,241,230,.62)`

**Typography**
- Sans: **DM Sans** (400/500/600/700) — UI labels, buttons, titles.
- Mono: **DM Mono** (400/500) — status text, IP/values, filenames, indicator labels, version.
- Sizes: title 22 / record 16 / button 15–16 / value 15 / body 13 / status 12 / section-label & indicator 10–11.

**Radii:** panel 0 (square); buttons 13–14; wells 13; cards 15.

**Shadows**
- Raised (buttons): `6px 6px 14px rgba(0,0,0,.5), -5px -5px 12px rgba(120,220,175,.07), inset 0 1px 0 rgba(150,230,190,.10)`
- Recessed (wells/cards/disabled): `inset 5px 5px 11px rgba(0,0,0,.72), inset -3px -3px 9px rgba(95,216,166,.07)`
- Panel inset bevel: `inset 6px 6px 16px rgba(0,0,0,.55), inset -6px -6px 16px rgba(120,220,175,.04), 0 30px 70px -24px rgba(0,0,0,.8)`
- Dot glow (on): `0 0 8px <color>`

**Spacing:** panel padding 28; section gaps via 22px dividers; grid/row gaps 12; indicator row gap 22.

## Assets
- **Fonts:** DM Sans + DM Mono (Google Fonts). Bundle the font files with the plugin (no network at runtime).
- **Grain texture:** generated fractal-noise SVG in the prototype; ship as a small tiling PNG/texture or generate procedurally. Low opacity, `overlay` blend.
- No icon assets — the only glyphs are the drag grip `⠿` and hint arrow `↗` (use real icons or keep as glyphs).
- No image assets; waveform/piano-roll are drawn from real audio/MIDI data.

## Files
- `CollabSync UI.dc.html` — the design prototype (all states viewable via the S/M/L + state toggle at the top, which is a design aid, not part of the plugin).
- `support.js` — the design-tool runtime only. **Ignore for implementation.**
